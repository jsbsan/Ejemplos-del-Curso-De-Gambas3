#include <stdio.h>
int main(int argc, char **argv)
{
int contador=0;
while (contador<10){
if (contador==2){
        printf("Has llegado al dos");
} else {
        printf("Vas por el...");
        printf("%d",contador);
}
    contador++;
}
printf("Fin del programa");
return 0;
}











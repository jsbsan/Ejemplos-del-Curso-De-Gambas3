#include <stdio.h>
int main(int argc, char **argv)
{
int contador=0;
printf("Hola buenos dias \n");
while (contador<10){
if (contador==2){
        printf("Has llegado a dos \n");
} else {
        printf("El numero por donde va...");
        printf("%d",contador);
        printf("\n");
}
    contador++;
}
printf("Fin del programa \n");
return 0;
}














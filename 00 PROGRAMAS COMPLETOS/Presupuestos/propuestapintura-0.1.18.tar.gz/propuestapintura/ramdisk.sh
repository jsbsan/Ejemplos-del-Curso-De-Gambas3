echo CONTRASENNA|sudo mkdir -p /media/myRamDisk
echo CONTRASENNA|sudo mount -t tmpfs none /media/myRamDisk -o size=TAMANOm
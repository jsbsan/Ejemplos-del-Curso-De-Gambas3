![img](http://2.bp.blogspot.com/-2HGvEXhUTzE/VOYxAm5D2zI/AAAAAAAALF8/8n4fqfpLylA/s1600/helptranslator%2Btraductor%2Bayuda%2Bprograma.png)

# helptranslator

Programa para ayudar a traducir otros programas.

Para mas ayuda y videos explicativos:

http://jsbsan.blogspot.com.es/2016/10/nueva-version-helptranslator-009.html


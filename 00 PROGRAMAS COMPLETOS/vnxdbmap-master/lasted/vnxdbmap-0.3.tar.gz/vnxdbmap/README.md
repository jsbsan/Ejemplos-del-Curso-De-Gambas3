
Mini framework (marco de trabajo), que genera el codigo de los datos de la base de datos.

Mini framework (work programin system), which generates code from the database objects.

ABOUT/ACERCA
============

**Visite o lea el archivo [docs/READMEes.md](docs/READMEes.md) para español.**

**Read or visit the file [docs/READMEen.md](docs/READMEen.md) on english.**

El software estaba originalmente en http://mapbdvistas.blogspot.com.es/ pero el desarrollo estaba detenido.

The software was originally at: http://mapbdvistas.blogspot.com.es/ but development had been staled.

Download/Descargar
==================

El directorio [lasted](lasted) siempre tiene la version final, si prefiere puede usar los tags para mas viejas.Si usas los tags, deberas compilarlo desde el IDE Gambas.

The directory [lasted](lasted) have a final release always, but if you wish use the release tags for older versions. IF download from tags, must compile it from IDE of Gambas.

Contribute/Contribuir
=====================

1. Fork the repository to a GitLab personal account or similar.
2. Clone the repository `git clone https://github.com/<youraccount>/vnxdbmap.git`
3. made changes, save, ...
4. commit changes `git push` to your repository
5. make a pull request to see your contribution and then try to merge...

LICENSE
=======

Temporally have a license that requires share alike attribution and non comercial usage unless have the permission to:
Temporalmente es uan licencia que requiere atribucion original y compartir igual, y comercializacion con permiso de autores:

   This program its under a license that required the CC-BY-SA rules.
   Cant be used commercialy unless permision of Julio Sanchez B jusabejusabe@gmail.com
   .
   This program Is Distributed In the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty Of
   MERCHANTABILITY Or FITNESS For A PARTICULAR PURPOSE. If you want 
   some kind of support please comunicate in https://gitlab.com/venenux/vnxdbmap 
   and provide some contribution to the project


-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema maquiladora_v_2
--

CREATE DATABASE IF NOT EXISTS maquiladora_v_2;
USE maquiladora_v_2;

--
-- Definition of table `maquiladora_v_2`.`AC_Maquiladores`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`AC_Maquiladores`;
CREATE TABLE  `maquiladora_v_2`.`AC_Maquiladores` (
  `ID_maquilador` int(11) NOT NULL,
  `Ac_piezas` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`AC_Maquiladores`
--

/*!40000 ALTER TABLE `AC_Maquiladores` DISABLE KEYS */;
LOCK TABLES `AC_Maquiladores` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `AC_Maquiladores` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Ac_Devoluciones`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Ac_Devoluciones`;
CREATE TABLE  `maquiladora_v_2`.`Ac_Devoluciones` (
  `ID_corte` int(11) NOT NULL,
  `Ac_piezas` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Ac_Devoluciones`
--

/*!40000 ALTER TABLE `Ac_Devoluciones` DISABLE KEYS */;
LOCK TABLES `Ac_Devoluciones` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Ac_Devoluciones` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Acumulado_Clientes`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Acumulado_Clientes`;
CREATE TABLE  `maquiladora_v_2`.`Acumulado_Clientes` (
  `ID_cliente` int(11) NOT NULL,
  `Ac_piezas` int(11) NOT NULL,
  `Ac_dinero` int(11) NOT NULL,
  `Fecha_venta` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Acumulado_Clientes`
--

/*!40000 ALTER TABLE `Acumulado_Clientes` DISABLE KEYS */;
LOCK TABLES `Acumulado_Clientes` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Acumulado_Clientes` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Acumulado_Cortadores`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Acumulado_Cortadores`;
CREATE TABLE  `maquiladora_v_2`.`Acumulado_Cortadores` (
  `ID_cortador` int(11) NOT NULL,
  `Ac_piezas` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Acumulado_Cortadores`
--

/*!40000 ALTER TABLE `Acumulado_Cortadores` DISABLE KEYS */;
LOCK TABLES `Acumulado_Cortadores` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Acumulado_Cortadores` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Acumulado_Corte`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Acumulado_Corte`;
CREATE TABLE  `maquiladora_v_2`.`Acumulado_Corte` (
  `ID_corte` int(11) NOT NULL,
  `Ac_cortado` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  `ID_color` int(11) NOT NULL,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Acumulado_Corte`
--

/*!40000 ALTER TABLE `Acumulado_Corte` DISABLE KEYS */;
LOCK TABLES `Acumulado_Corte` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Acumulado_Corte` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Acumulado_Maquilado`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Acumulado_Maquilado`;
CREATE TABLE  `maquiladora_v_2`.`Acumulado_Maquilado` (
  `ID_corte` int(11) NOT NULL,
  `Ac_maquilado` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Acumulado_Maquilado`
--

/*!40000 ALTER TABLE `Acumulado_Maquilado` DISABLE KEYS */;
LOCK TABLES `Acumulado_Maquilado` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Acumulado_Maquilado` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Acumulado_Modelos`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Acumulado_Modelos`;
CREATE TABLE  `maquiladora_v_2`.`Acumulado_Modelos` (
  `ID_corte` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `Ac_dinero` int(11) NOT NULL,
  `Ac_piezas` int(11) NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Acumulado_Modelos`
--

/*!40000 ALTER TABLE `Acumulado_Modelos` DISABLE KEYS */;
LOCK TABLES `Acumulado_Modelos` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Acumulado_Modelos` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Acumulado_Plazas`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Acumulado_Plazas`;
CREATE TABLE  `maquiladora_v_2`.`Acumulado_Plazas` (
  `ID_plaza` int(11) NOT NULL,
  `Ac_piezas` int(11) NOT NULL,
  `Ac_dinero` int(11) NOT NULL,
  `Fecha_venta` date NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Acumulado_Plazas`
--

/*!40000 ALTER TABLE `Acumulado_Plazas` DISABLE KEYS */;
LOCK TABLES `Acumulado_Plazas` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Acumulado_Plazas` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Administrador`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Administrador`;
CREATE TABLE  `maquiladora_v_2`.`Administrador` (
  `Usuario` char(1) NOT NULL,
  `Pass` char(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Administrador`
--

/*!40000 ALTER TABLE `Administrador` DISABLE KEYS */;
LOCK TABLES `Administrador` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Administrador` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Almacen`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Almacen`;
CREATE TABLE  `maquiladora_v_2`.`Almacen` (
  `ID_corte` int(11) NOT NULL auto_increment,
  `Cantidad_existente` int(11) NOT NULL,
  `Nombre_modelo` char(25) default NULL,
  PRIMARY KEY  (`ID_corte`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Almacen`
--

/*!40000 ALTER TABLE `Almacen` DISABLE KEYS */;
LOCK TABLES `Almacen` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Almacen` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Aminstrador`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Aminstrador`;
CREATE TABLE  `maquiladora_v_2`.`Aminstrador` (
  `Usuario` char(20) NOT NULL,
  `Pass` char(20) NOT NULL,
  `ID_usuario` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`ID_usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Aminstrador`
--

/*!40000 ALTER TABLE `Aminstrador` DISABLE KEYS */;
LOCK TABLES `Aminstrador` WRITE;
INSERT INTO `maquiladora_v_2`.`Aminstrador` VALUES  ('Usuario','usuario',2),
 ('ADMIN','ponz',1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `Aminstrador` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Clientes`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Clientes`;
CREATE TABLE  `maquiladora_v_2`.`Clientes` (
  `ID_cliente` int(11) NOT NULL auto_increment,
  `Nombre_cliente` char(50) default NULL,
  `Direccion` char(60) default NULL,
  `Telefono` char(15) default NULL,
  PRIMARY KEY  (`ID_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Clientes`
--

/*!40000 ALTER TABLE `Clientes` DISABLE KEYS */;
LOCK TABLES `Clientes` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Clientes` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Colores`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Colores`;
CREATE TABLE  `maquiladora_v_2`.`Colores` (
  `ID_color` int(11) NOT NULL auto_increment,
  `Nombre_color` char(20) default NULL,
  `Nombre_modelo` char(20) NOT NULL,
  PRIMARY KEY  (`ID_color`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Colores`
--

/*!40000 ALTER TABLE `Colores` DISABLE KEYS */;
LOCK TABLES `Colores` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Colores` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Colors`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Colors`;
CREATE TABLE  `maquiladora_v_2`.`Colors` (
  `ID_color` int(11) NOT NULL auto_increment,
  `color` char(20) NOT NULL,
  PRIMARY KEY  USING BTREE (`ID_color`)
) ENGINE=MyISAM AUTO_INCREMENT=100019 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Colors`
--

/*!40000 ALTER TABLE `Colors` DISABLE KEYS */;
LOCK TABLES `Colors` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Colors` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Compraventa`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Compraventa`;
CREATE TABLE  `maquiladora_v_2`.`Compraventa` (
  `Contador` int(11) NOT NULL auto_increment,
  `Folio` int(11) NOT NULL,
  `ID_corte` int(11) NOT NULL,
  `Precio_unitario` int(11) NOT NULL,
  `Cantidad_vendida` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY  (`Contador`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Compraventa`
--

/*!40000 ALTER TABLE `Compraventa` DISABLE KEYS */;
LOCK TABLES `Compraventa` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Compraventa` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Cortadores`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Cortadores`;
CREATE TABLE  `maquiladora_v_2`.`Cortadores` (
  `ID_cortador` int(11) NOT NULL auto_increment,
  `Nombre_cortador` char(50) default NULL,
  `Direccion` char(60) default NULL,
  `Telefono` char(15) default NULL,
  PRIMARY KEY  (`ID_cortador`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Cortadores`
--

/*!40000 ALTER TABLE `Cortadores` DISABLE KEYS */;
LOCK TABLES `Cortadores` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Cortadores` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Devolucion`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Devolucion`;
CREATE TABLE  `maquiladora_v_2`.`Devolucion` (
  `Folio` int(11) NOT NULL,
  `ID_corte` int(11) NOT NULL,
  `Cantidad_devuelta` int(11) NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  `Fecha_devolucion` date NOT NULL,
  `ID_cliente` int(11) NOT NULL,
  `ID_plazas` int(11) NOT NULL,
  PRIMARY KEY  USING BTREE (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Devolucion`
--

/*!40000 ALTER TABLE `Devolucion` DISABLE KEYS */;
LOCK TABLES `Devolucion` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Devolucion` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Maquiladores`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Maquiladores`;
CREATE TABLE  `maquiladora_v_2`.`Maquiladores` (
  `ID_maquilador` int(11) NOT NULL auto_increment,
  `Nombre_maquilador` char(50) default NULL,
  `Direccion` char(60) default NULL,
  `Telefono` char(15) default NULL,
  PRIMARY KEY  (`ID_maquilador`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Maquiladores`
--

/*!40000 ALTER TABLE `Maquiladores` DISABLE KEYS */;
LOCK TABLES `Maquiladores` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Maquiladores` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Notas`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Notas`;
CREATE TABLE  `maquiladora_v_2`.`Notas` (
  `Folio` int(11) NOT NULL,
  `ID_cliente` int(11) NOT NULL,
  `ID_plazas` int(11) NOT NULL,
  `Fecha_venta` date NOT NULL,
  PRIMARY KEY  (`Folio`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Notas`
--

/*!40000 ALTER TABLE `Notas` DISABLE KEYS */;
LOCK TABLES `Notas` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Notas` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Plazas`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Plazas`;
CREATE TABLE  `maquiladora_v_2`.`Plazas` (
  `ID_plazas` int(11) NOT NULL auto_increment,
  `Nombre_plaza` char(50) default NULL,
  `Direccion` char(60) default NULL,
  `Telefono` char(15) default NULL,
  PRIMARY KEY  (`ID_plazas`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Plazas`
--

/*!40000 ALTER TABLE `Plazas` DISABLE KEYS */;
LOCK TABLES `Plazas` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Plazas` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Producto_Cortado`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Producto_Cortado`;
CREATE TABLE  `maquiladora_v_2`.`Producto_Cortado` (
  `ID_cortador` int(11) NOT NULL,
  `ID_corte` int(11) NOT NULL,
  `Fecha_entrega` date NOT NULL,
  `Cantidad_cortada` int(11) NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  `ID_color` int(11) NOT NULL,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Producto_Cortado`
--

/*!40000 ALTER TABLE `Producto_Cortado` DISABLE KEYS */;
LOCK TABLES `Producto_Cortado` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Producto_Cortado` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Producto_Maquilado`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Producto_Maquilado`;
CREATE TABLE  `maquiladora_v_2`.`Producto_Maquilado` (
  `ID_maquilador` int(11) NOT NULL,
  `ID_corte` int(11) NOT NULL,
  `Fecha_se_lleva` date NOT NULL,
  `Cantidad_se_lleva` int(11) NOT NULL,
  `Cantidad_devuelve` int(11) NOT NULL,
  `contador` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`contador`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Producto_Maquilado`
--

/*!40000 ALTER TABLE `Producto_Maquilado` DISABLE KEYS */;
LOCK TABLES `Producto_Maquilado` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Producto_Maquilado` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`TV_Clientes`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`TV_Clientes`;
CREATE TABLE  `maquiladora_v_2`.`TV_Clientes` (
  `ID_corte` int(11) NOT NULL,
  `Precio_unitario` int(11) NOT NULL,
  `Cantidad_vendida` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Folio` int(11) NOT NULL,
  `contador` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`TV_Clientes`
--

/*!40000 ALTER TABLE `TV_Clientes` DISABLE KEYS */;
LOCK TABLES `TV_Clientes` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `TV_Clientes` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`TV_Maquila`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`TV_Maquila`;
CREATE TABLE  `maquiladora_v_2`.`TV_Maquila` (
  `ID_corte` int(11) NOT NULL,
  `Cantidad_lleva` int(11) NOT NULL,
  `Cantidad_devuelve` int(11) NOT NULL,
  `contador` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`TV_Maquila`
--

/*!40000 ALTER TABLE `TV_Maquila` DISABLE KEYS */;
LOCK TABLES `TV_Maquila` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `TV_Maquila` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`TV_Plazas`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`TV_Plazas`;
CREATE TABLE  `maquiladora_v_2`.`TV_Plazas` (
  `ID_corte` int(11) NOT NULL,
  `Precio_unitario` int(11) NOT NULL,
  `Cantidad_vendida` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Folio` int(11) NOT NULL,
  `contador` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`TV_Plazas`
--

/*!40000 ALTER TABLE `TV_Plazas` DISABLE KEYS */;
LOCK TABLES `TV_Plazas` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `TV_Plazas` ENABLE KEYS */;


--
-- Definition of table `maquiladora_v_2`.`Tv_Corte`
--

DROP TABLE IF EXISTS `maquiladora_v_2`.`Tv_Corte`;
CREATE TABLE  `maquiladora_v_2`.`Tv_Corte` (
  `ID_corte` int(11) NOT NULL,
  `Cantidad_cortada` int(11) NOT NULL,
  `ID_color` int(11) NOT NULL,
  `contador` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maquiladora_v_2`.`Tv_Corte`
--

/*!40000 ALTER TABLE `Tv_Corte` DISABLE KEYS */;
LOCK TABLES `Tv_Corte` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `Tv_Corte` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
